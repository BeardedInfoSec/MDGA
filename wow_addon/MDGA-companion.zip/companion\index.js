#!/usr/bin/env node
// ================================================
// MDGA COMPANION APP
// Watches WoW SavedVariables file, parses Lua data,
// POSTs new events/roster to the MDGA server.
// Officer-only: hard-stops if playerInfo.rankIndex > 2.
// ================================================
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const chokidar = require('chokidar');
const fetch = require('node-fetch');
const { parseLuaFile } = require('./lua-parser');
const { runWizard } = require('./setup');

// When packaged with pkg, __dirname points inside the snapshot (read-only).
// Use the directory of the running exe so config.json sits next to it.
const APP_DIR = process.pkg ? path.dirname(process.execPath) : __dirname;
const CONFIG_PATH = path.join(APP_DIR, 'config.json');
const FORCE_SETUP = process.argv.includes('--setup') || process.argv.includes('--reconfigure');

async function loadOrCreateConfig() {
  if (FORCE_SETUP || !fs.existsSync(CONFIG_PATH)) {
    return await runWizard(CONFIG_PATH);
  }
  const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  if (!cfg.serverUrl || !cfg.token || !cfg.wowPath || !cfg.accountName) {
    console.log('[MDGA] config.json is incomplete — running setup wizard.');
    return await runWizard(CONFIG_PATH);
  }
  return cfg;
}

// Config + watch path are populated by main() after the wizard runs.
let config;
let SAVED_VARS_PATH;

// ── Constants ──
const OFFICER_RANK_THRESHOLD = 2;
const STATE_FILE = path.join(APP_DIR, 'companion-state.json');
const QUEUE_FILE = path.join(APP_DIR, 'companion-queue.json');
const MAX_RETRY_DELAY_MS = 5 * 60 * 1000; // 5 minutes
const BASE_RETRY_DELAY_MS = 5000;

// ── State management ──
function loadState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    return { lastSyncedEventId: null, lastRosterHash: null, lastSyncTimestamp: 0, lastReportAt: 0 };
  }
}

function saveState(state) {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

// ── Queue management (for retry on failure) ──
function loadQueue() {
  try {
    return JSON.parse(fs.readFileSync(QUEUE_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveQueue(queue) {
  fs.writeFileSync(QUEUE_FILE, JSON.stringify(queue, null, 2));
}

// ── CSV report writer ──
// Triggered when the addon stages MDGA_Data.pendingReport via the in-game
// "Generate Report" button + /reload. Writes to the user's Desktop as
// MDGA_roster_MM-DD-YYYY.csv. Overwrites on same-day reruns.
function csvEscape(val) {
  const s = val == null ? '' : String(val);
  if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function getDesktopPath() {
  // Allow config override; otherwise use OS default.
  if (config.reportDir) return config.reportDir;
  return path.join(os.homedir(), 'Desktop');
}

function formatDateMMDDYYYY(epochSec) {
  const d = epochSec ? new Date(epochSec * 1000) : new Date();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const yyyy = d.getFullYear();
  return `${mm}-${dd}-${yyyy}`;
}

function formatTimeHHMMSS(epochSec) {
  const d = epochSec ? new Date(epochSec * 1000) : new Date();
  return `${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}${String(d.getSeconds()).padStart(2, '0')}`;
}

// Sanitize a guild name for use in a filename: replace spaces and any
// character that Windows/POSIX disallows with underscores, collapse runs.
function slugifyGuildName(name) {
  return String(name || 'Unknown')
    .trim()
    .replace(/[\\/:*?"<>|\s]+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    || 'Unknown';
}

function writeReportCsv(report) {
  if (!report || !Array.isArray(report.roster)) return null;
  const header = [
    'Name', 'Realm', 'Class', 'Level', 'Rank', 'RankIndex',
    'Online', 'Zone', 'LastSeen', 'PublicNote', 'OfficerNote',
  ];
  const lines = [header.map(csvEscape).join(',')];

  const sorted = [...report.roster].sort((a, b) => {
    const ra = (a.rankIndex ?? 99) - (b.rankIndex ?? 99);
    if (ra !== 0) return ra;
    return String(a.name || '').localeCompare(String(b.name || ''));
  });

  for (const m of sorted) {
    const lastSeenStr = m.lastSeen
      ? new Date(m.lastSeen * 1000).toISOString().replace('T', ' ').slice(0, 19)
      : '';
    lines.push([
      m.name, m.realmSlug, m.class, m.level ?? '',
      m.rankName, m.rankIndex ?? '',
      m.isOnline ? 'Yes' : 'No',
      m.zone, lastSeenStr,
      m.publicNote, m.officerNote,
    ].map(csvEscape).join(','));
  }

  const dir = getDesktopPath();
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const guildSlug = slugifyGuildName(report.guildInfo && report.guildInfo.name);
  const date = formatDateMMDDYYYY(report.generatedAt);
  const time = formatTimeHHMMSS(report.generatedAt);
  const filename = `MDGA_roster_${guildSlug}_${date}_${time}.csv`;
  const outPath = path.join(dir, filename);
  fs.writeFileSync(outPath, lines.join('\r\n'), 'utf8');
  return outPath;
}

// ── Roster hashing for change detection ──
function hashRoster(roster) {
  if (!roster || typeof roster !== 'object') return 'empty';
  const keys = Object.keys(roster).sort();
  const parts = keys.map((k) => {
    const m = roster[k];
    return `${k}:${m.rankIndex}:${m.level}:${m.class}`;
  });
  return crypto.createHash('sha256').update(parts.join('|')).digest('hex').substring(0, 16);
}

// ── POST to server ──
let retryCount = 0;

async function postToServer(payload) {
  const res = await fetch(`${config.serverUrl}/api/addon/sync`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${config.token}`,
    },
    body: JSON.stringify(payload),
    timeout: 30000,
  });

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Server responded ${res.status}: ${body}`);
  }

  return res.json();
}

// ── Process SavedVariables file ──
async function processFile() {
  if (!fs.existsSync(SAVED_VARS_PATH)) {
    if (config.debug) console.log('[MDGA] SavedVariables file not found yet.');
    return;
  }

  let parsed;
  try {
    parsed = parseLuaFile(SAVED_VARS_PATH);
  } catch (err) {
    console.error('[MDGA] Failed to parse SavedVariables:', err.message);
    return;
  }

  const data = parsed?.MDGA_Data;
  if (!data) {
    if (config.debug) console.log('[MDGA] MDGA_Data not found in SavedVariables.');
    return;
  }

  if (data.version !== 3) {
    console.log(`[MDGA] Unsupported schema version: ${data.version}. Expected 3.`);
    return;
  }

  // ── Desktop CSV report: independent of the /sync flow. If the user clicked
  //    "Generate Report" in-game, pendingReport has a fresh generatedAt. We
  //    write a CSV to Desktop once per unique generatedAt, then continue to
  //    the normal sync below.
  const stateForReport = loadState();
  const report = data.pendingReport;
  if (report && Number(report.generatedAt) > Number(stateForReport.lastReportAt || 0)) {
    try {
      const outPath = writeReportCsv(report);
      if (outPath) {
        console.log(`[MDGA] CSV report written: ${outPath} (${(report.roster || []).length} members)`);
        stateForReport.lastReportAt = Number(report.generatedAt);
        saveState(stateForReport);
      }
    } catch (err) {
      console.error(`[MDGA] CSV report failed: ${err.message}`);
    }
  }

  // ── OFFICER CHECK (companion-level hard stop) ──
  const rankIndex = data.playerInfo?.rankIndex;
  if (rankIndex === undefined || rankIndex === null || rankIndex > OFFICER_RANK_THRESHOLD) {
    console.log(`[MDGA] BLOCKED: Player rank ${rankIndex} exceeds officer threshold (${OFFICER_RANK_THRESHOLD}). Upload denied.`);
    return;
  }

  const state = loadState();

  // ── Determine which events are new ──
  let newEvents = data.events || [];
  if (state.lastSyncedEventId && Array.isArray(newEvents)) {
    const idx = newEvents.findIndex((e) => e.id === state.lastSyncedEventId);
    if (idx >= 0) {
      newEvents = newEvents.slice(idx + 1);
    }
    // If not found, send all (events were trimmed or first sync)
  }

  // ── Determine if roster changed ──
  const currentRosterHash = hashRoster(data.roster);
  const rosterChanged = currentRosterHash !== state.lastRosterHash;

  // ── Skip if nothing new ──
  if (newEvents.length === 0 && !rosterChanged) {
    if (config.debug) console.log('[MDGA] No changes to sync.');
    return;
  }

  // ── Build payload ──
  const payload = {
    addonVersion: data.addonVersion,
    schemaVersion: data.version,
    capturedBy: data.capturedBy,
    capturedAt: data.capturedAt,
    guildInfo: data.guildInfo,
    playerInfo: data.playerInfo,
    roster: rosterChanged ? Object.values(data.roster || {}) : undefined,
    events: newEvents.length > 0 ? newEvents : undefined,
    rosterIncluded: rosterChanged,
  };

  // ── Attempt upload ──
  try {
    const result = await postToServer(payload);
    console.log(`[MDGA] Sync success: events=${result.eventsProcessed || 0}, roster=${result.rosterProcessed || 0}, rankChanges=${result.rankChangesTriggered || 0}`);

    // Update state
    const allEvents = data.events || [];
    state.lastSyncedEventId = allEvents.length > 0 ? allEvents[allEvents.length - 1].id : state.lastSyncedEventId;
    state.lastRosterHash = currentRosterHash;
    state.lastSyncTimestamp = Date.now();
    saveState(state);

    retryCount = 0; // reset backoff

    // Drain any queued payloads
    await drainQueue();
  } catch (err) {
    console.error(`[MDGA] Sync failed: ${err.message}`);

    // Queue the payload for retry
    const queue = loadQueue();
    queue.push({ payload, queuedAt: Date.now() });
    // Keep max 50 queued payloads
    while (queue.length > 50) queue.shift();
    saveQueue(queue);

    // Schedule retry with exponential backoff
    retryCount++;
    const delay = Math.min(BASE_RETRY_DELAY_MS * Math.pow(2, retryCount - 1), MAX_RETRY_DELAY_MS);
    console.log(`[MDGA] Will retry in ${Math.round(delay / 1000)}s (attempt ${retryCount})`);
    setTimeout(drainQueue, delay);
  }
}

async function drainQueue() {
  const queue = loadQueue();
  if (queue.length === 0) return;

  const remaining = [];
  for (const item of queue) {
    try {
      const result = await postToServer(item.payload);
      console.log(`[MDGA] Queue item synced: events=${result.eventsProcessed || 0}`);
    } catch (err) {
      console.error(`[MDGA] Queue item failed: ${err.message}`);
      remaining.push(item);
    }
  }

  saveQueue(remaining);
  if (remaining.length === 0) {
    retryCount = 0;
  }
}

// ── Main ──
async function main() {
  config = await loadOrCreateConfig();
  SAVED_VARS_PATH = path.join(
    config.wowPath, 'WTF', 'Account', config.accountName,
    'SavedVariables', 'MDGA.lua'
  );

  console.log(`[MDGA] Companion app v1.5.0`);
  console.log(`[MDGA] Watching: ${SAVED_VARS_PATH}`);
  console.log(`[MDGA] Server: ${config.serverUrl}`);

  const watcher = chokidar.watch(SAVED_VARS_PATH, {
    persistent: true,
    awaitWriteFinish: {
      stabilityThreshold: 2000, // wait 2s after last write
      pollInterval: 500,
    },
    ignoreInitial: false,
  });

  watcher.on('add', () => {
    console.log('[MDGA] SavedVariables file detected.');
    processFile();
  });

  watcher.on('change', () => {
    console.log('[MDGA] SavedVariables changed, syncing...');
    processFile();
  });

  watcher.on('error', (err) => {
    console.error('[MDGA] Watcher error:', err.message);
  });

  // Run initial sync after 2 seconds
  setTimeout(processFile, 2000);
}

main().catch((err) => {
  console.error('[MDGA] Fatal:', err);
  // When run by double-click, the user expects to see the error before the
  // window closes. Pause for a keystroke.
  if (process.stdin.isTTY) {
    console.log('\nPress Enter to close.');
    process.stdin.resume();
    process.stdin.once('data', () => process.exit(1));
  } else {
    process.exit(1);
  }
});
